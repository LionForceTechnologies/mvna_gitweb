module.exports = {
  footerText: 'Copyright MED.VET.NET Association © 2020',
}
