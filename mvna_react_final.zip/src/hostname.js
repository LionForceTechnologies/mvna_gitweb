export  const hostname = 'https://dktiyxy955yvi.cloudfront.net';
// http://localhost:8080
// https://dktiyxy955yvi.cloudfront.net
// http://mvnaapp-env.eba-fp26j2fq.ap-south-1.elasticbeanstalk.com  
