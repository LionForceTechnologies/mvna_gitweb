
// The timer components reference name, ie. the block's name and the component's name
export const timerRef = 'confuse';

// The plugin's reference. Must be passed to <GEditor plugins=[{...}]/>
export const timerPluginRef = 'jukin';


export const loadHtmltemplate = 'load-html-template';
