export const Colors = {
    HEADER: 'HEADER',
    TEXT: 'TEXT',
  }
  