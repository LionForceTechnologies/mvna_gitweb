import React, {useEffect} from "react";
import {Button, Checkbox, Form, Input} from "antd";
import {useDispatch, useSelector} from "react-redux";
import {Link} from "react-router-dom";
import App from "./components/App" 


// if (window.location.pathname.indexOf('/user') !== -1) {
//   // alert(15)
  

// }
const UserDashboard = (props) => {
  
  return (
    <div>
<App />
    </div>
  );
};

export default UserDashboard;
